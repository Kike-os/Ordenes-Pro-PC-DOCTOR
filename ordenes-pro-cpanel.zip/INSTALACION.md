# Instalación Python en cPanel

Paquete para Python 3.11 y Passenger. No contiene cuentas, datos locales ni secretos. Todavía requiere una prueba en el hosting.

1. En Setup Python App, usar raíz `ordenes-pro`, URL `ordenes-pro.ecuadorpcdoctor.com` sin ruta, archivo `passenger_wsgi.py` y entrada `application`.
2. En Administrador de archivos abrir la raíz de aplicación indicada por cPanel, normalmente `/home/TU_USUARIO/ordenes-pro`. Debe estar fuera de `public_html`. Si la raíz elegida está dentro de `public_html`, cambiarla antes de subir archivos. La URL pública se configura por separado.
3. Si existe un `passenger_wsgi.py` de ejemplo, descargarlo como respaldo. Subir el ZIP y extraerlo en la raíz de aplicación. `app.py` y `passenger_wsgi.py` deben quedar directamente dentro de ella. No borrar archivos de configuración generados por cPanel. Eliminar el ZIP del hosting después de extraerlo.
4. Configurar variables en Setup Python App: `APP_URL=https://ordenes-pro.ecuadorpcdoctor.com` y `SESSION_SECURE=true`. No copiar el `.env` local. El paquete incluye bibliotecas portables de QR/PDF y sus licencias; no necesita instalar dependencias con pip. Configurar PUBLIC_APP_URL con la misma URL HTTPS para los QR. Ver [recepción y encabezado](RECEPCION.md) para clima y habilitación explícita de producción.
5. Abrir Terminal de cPanel y pegar el comando de activación del entorno virtual que muestra Setup Python App. En esa misma terminal, situarse en la raíz de aplicación y ejecutar `python app.py migrate`, después `python app.py create-admin`. El segundo comando solicita nombre, usuario, correo y contraseña sin mostrarla. Si no hay Terminal, solicitar al proveedor que habilite acceso a una terminal para estos comandos; no crear una ruta web pública para configurar administradores.
6. Activar/comprobar el certificado del subdominio en SSL/TLS Status (AutoSSL). Configurar la redirección HTTPS únicamente para ese subdominio. Reiniciar la aplicación desde Setup Python App.
7. Abrir `https://ordenes-pro.ecuadorpcdoctor.com`, iniciar sesión y crear una orden ficticia. Comprobar consulta, cambios de estado y cierre de sesión. No usar datos reales hasta terminar estas pruebas.

Para recuperar contraseñas configurar SMTP_HOST, SMTP_PORT (587), SMTP_USER, SMTP_PASSWORD y SMTP_FROM como variables privadas. Sin SMTP, la recuperación no envía correos.

La base SQLite se crea en `var/ordenes.sqlite3`. Conservar y respaldar `var` en futuras actualizaciones; no sobrescribirlo ni subir la base de evaluación local. No requiere MySQL. Confirmar con el proveedor que el almacenamiento permite bloqueos SQLite antes de uso concurrente.

Ante error 500/503 consultar el registro de Passenger en cPanel y compartir solo el mensaje, sin credenciales. Para revertir la primera instalación, detener la aplicación y restaurar el archivo de inicio respaldado; conservar `var`.

Referencia: https://docs.cpanel.net/knowledge-base/web-services/how-to-install-a-python-wsgi-application/

## Actualización del formulario y diagnóstico de catálogos

Actualizar **todo** el paquete, conservando `var/` y las variables privadas. No subir únicamente `static/app.js` o `dashboard.html`: un frontend nuevo con un backend anterior produce HTTP 404 en `/api/reception-options` y `/api/geo/*`.

Con la aplicación detenida desde cPanel, respaldar `var/`, extraer el paquete actualizado en la raíz Python y ejecutar `python app.py migrate` en el entorno virtual. Reiniciar Passenger desde Setup Python App. El paquete incluye `reception.py`, `geography.py`, `weather.py`, `receipt_pdf.py`, `data/inec-2026.json`, las cuatro migraciones y las bibliotecas de `vendor/`. Las rutas de datos se resuelven desde el archivo Python, no desde el directorio de trabajo.

Tras iniciar sesión, en Red/Network del navegador comprobar respuestas JSON HTTP 200 para:

- `/api/reception-options`: ocho tipos y catálogo de marcas.
- `/api/geo/provinces`: 24 provincias.
- `/api/geo/cantons?province=01`: 15 cantones de Azuay.
- `/api/geo/parishes?province=01&canton=0101`: parroquias de Cuenca.
- `/api/geo/localities?canton=0101&parish=010101`: sugerencias de localidad; una lista vacía es válida y permite escritura manual.

HTTP 401 indica una sesión ausente/caducada; HTTP 404 con «Recurso no disponible» indica rutas ausentes en la versión que está ejecutándose o una configuración incorrecta de Passenger. HTTP 500 requiere revisar el traceback del registro de Passenger: ahora se registra la excepción con método y ruta, sin volcar datos del formulario. Una tabla inexistente se corrige ejecutando las migraciones con la aplicación detenida, no ocultando el error. Mantener la aplicación en la raíz de su subdominio; el cliente utiliza rutas absolutas del mismo origen y no necesita CORS.

Verificar permisos de lectura de código, JSON y `vendor/`, y de escritura de `var/` para el usuario que ejecuta Python. Nunca habilitar permisos universales 777 ni exponer `var/` o `.env` bajo `public_html`.
