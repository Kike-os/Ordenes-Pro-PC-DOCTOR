"""Evaluación local de ÓRDENES PRO. Loopback por defecto; LAN mediante configuración explícita."""
import argparse
import base64
import getpass
import hashlib
import hmac
import html
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import smtplib
import sqlite3
import ssl
import time
from email.message import EmailMessage
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit, unquote
from reception import (DEVICE_TYPES, validate_order, order_code, legacy_type, remember_brand, qr_image, production_enabled, reception_now, order_url, public_base_url)

import service_terms
from weather import current_weather
from geography import initialize_catalog, search as search_geography, METADATA as GEO_METADATA

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'var'
DB = DATA / 'ordenes.sqlite3'


def load_env():
    path = ROOT / '.env'
    if path.exists():
        for line in path.read_text().splitlines():
            if line.strip() and not line.lstrip().startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ.setdefault(key.strip(), value.strip())


class Connection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()


def connect():
    c = sqlite3.connect(DB, timeout=10, factory=Connection)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c


def migrate():
    DATA.mkdir(mode=0o700, parents=True, exist_ok=True)
    with connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS migrations (name TEXT PRIMARY KEY)')
        for p in sorted((ROOT / 'migrations').glob('*.sql')):
            if not c.execute('SELECT 1 FROM migrations WHERE name=?', (p.name,)).fetchone():
                if DB.exists() and c.execute('SELECT COUNT(*) FROM migrations').fetchone()[0]:
                    backup = DATA / f'backup-{time.time_ns()}.sqlite3'
                    target = sqlite3.connect(backup)
                    try:
                        c.backup(target)
                    finally:
                        target.close()
                    backup.chmod(0o600)
                name = p.name.replace("'", "''")
                c.executescript('BEGIN IMMEDIATE;\n' + p.read_text() + f"\nINSERT INTO migrations VALUES ('{name}');\nCOMMIT;")
        initialize_catalog(c)
        snapshot_rows = c.execute("SELECT o.id,c.name client,c.identification,c.document_type,c.trade_name,c.phone,c.email,c.province,c.province_code,c.canton,c.canton_code,c.parish,c.parish_code,c.city,c.locality_code,c.address,c.main_street,c.secondary_street,c.building_number,c.location_reference,c.geo_version,d.category type,d.brand,d.model,d.serial,d.color,o.accessories,o.physical_condition,o.problem,o.technician_notes FROM orders o JOIN devices d ON d.id=o.device_id JOIN clients c ON c.id=d.client_id WHERE o.reception_snapshot='' ").fetchall()
        for order in snapshot_rows:
            snapshot=dict(order)
            oid=snapshot.pop('id')
            c.execute('UPDATE orders SET reception_snapshot=? WHERE id=?',(json.dumps(snapshot,ensure_ascii=False),oid))
        for order in c.execute("SELECT id,code FROM orders WHERE qr_url=''").fetchall():
            c.execute('UPDATE orders SET qr_url=? WHERE id=?',(order_url(order['code']),order['id']))
    DB.chmod(0o600)


def password_hash(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=32768, r=8, p=3, maxmem=64*1024*1024)
    return 'scrypt$32768$8$3$' + base64.b64encode(salt).decode() + '$' + base64.b64encode(digest).decode()


def password_ok(password, encoded):
    try:
        kind, n, r, p, salt, expected = encoded.split('$')
        if kind != 'scrypt' or (n, r, p) != ('32768', '8', '3'):
            return False
        actual = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p), maxmem=64*1024*1024)
        return hmac.compare_digest(actual, base64.b64decode(expected))
    except (ValueError, TypeError):
        return False


DUMMY_HASH = password_hash(secrets.token_urlsafe(32))


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def audit(c, user_id, action, entity_id=None):
    c.execute('INSERT INTO audit(user_id,action,entity_id,created_at) VALUES (?,?,?,?)', (user_id, action, entity_id, int(time.time())))


def limited(c, bucket, limit=8, window=900):
    now = int(time.time())
    c.execute('DELETE FROM attempts WHERE expires<?', (now,))
    c.execute('INSERT INTO attempts VALUES (?,1,?) ON CONFLICT(bucket) DO UPDATE SET count=count+1', (bucket, now+window))
    return c.execute('SELECT count FROM attempts WHERE bucket=?', (bucket,)).fetchone()[0] > limit


def make_session(c, user_id, remember=False):
    token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
    age = 30*86400 if remember else 8*3600
    c.execute('DELETE FROM sessions WHERE expires<?', (int(time.time()),))
    c.execute('INSERT INTO sessions VALUES (?,?,?,?)', (digest(token), user_id, csrf, int(time.time())+age))
    return token, csrf, age


def send_reset(email, token):
    host = os.getenv('SMTP_HOST')
    sender = os.getenv('SMTP_FROM')
    if not host or not sender:
        raise RuntimeError('SMTP no configurado')
    msg = EmailMessage()
    msg['Subject'] = 'Restablecer acceso — ÓRDENES PRO'
    msg['From'], msg['To'] = sender, email
    url = os.getenv('APP_URL', 'http://127.0.0.1:8010').rstrip('/') + '/reset?token=' + token
    msg.set_content(f'Solicitaste restablecer tu contraseña. Este enlace vence en 20 minutos y solo se puede usar una vez:\n{url}\nSi no lo solicitaste, ignora este correo.')
    with smtplib.SMTP(host, int(os.getenv('SMTP_PORT', '587')), timeout=15) as smtp:
        smtp.starttls(context=ssl.create_default_context())
        if os.getenv('SMTP_USER'):
            smtp.login(os.environ['SMTP_USER'], os.getenv('SMTP_PASSWORD', ''))
        smtp.send_message(msg)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # No registrar URL de recuperación, contraseñas, tokens ni datos personales.
        pass

    def reply(self, status, body, content_type='application/json; charset=utf-8', cookie=None):
        if isinstance(body, dict):
            body = json.dumps(body, ensure_ascii=False).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.end_headers()
        self.wfile.write(body)

    def cookie(self, token, age=None):
        value = f'pcdoctor_session={token}; Path=/; HttpOnly; SameSite=Strict'
        if os.getenv('SESSION_SECURE', 'false').lower() == 'true':
            value += '; Secure'
        if age is not None:
            value += f'; Max-Age={age}'
        return value

    def session(self, c):
        cookies = SimpleCookie()
        try:
            cookies.load(self.headers.get('Cookie', ''))
            token = cookies['pcdoctor_session'].value if 'pcdoctor_session' in cookies else ''
        except Exception:
            token = ''
        return c.execute('SELECT u.id,u.username,u.name,u.email,u.role,s.csrf FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>? AND u.active=1', (digest(token), int(time.time()))).fetchone(), token

    def page(self, name):
        content = (ROOT / 'templates' / name).read_text()
        notice = '' if production_enabled() else '<p class="evaluation-notice">Esta versión es de evaluación. Utiliza únicamente datos ficticios.</p>'
        content = content.replace('{{evaluation_notice}}', notice).replace('{{environment_label}}', 'Servicio técnico' if production_enabled() else 'Evaluación local · Usa datos ficticios')
        self.reply(200, content, 'text/html; charset=utf-8')

    def do_GET(self):
        path = urlsplit(self.path).path
        files = {'/static/app.css':'app.css','/static/app.js':'app.js','/static/logo-original.png':'logo-original.png'}
        if path in files:
            file = ROOT / 'static' / files[path]
            if not file.is_file():
                return self.reply(404, {'error':'Archivo no disponible.'})
            content_type = 'image/png' if file.suffix == '.png' else ('text/css; charset=utf-8' if file.suffix == '.css' else 'text/javascript; charset=utf-8')
            return self.reply(200, file.read_bytes(), content_type)
        with connect() as c:
            public_terms=re.fullmatch(r'/conditions/([a-f0-9]{32})',path)
            if public_terms:
                row=c.execute('SELECT * FROM service_terms WHERE id=?',(public_terms[1],)).fetchone()
                if not row:return self.reply(404,{'error':'Versión de condiciones no disponible.'})
                return self.reply(200,service_terms.public_page(row),'text/html; charset=utf-8')
            user, _ = self.session(c)
            if path in ('/', '/login') or re.fullmatch(r'/orders/[^/]{1,80}',path):
                return self.page('dashboard.html' if user else 'login.html')
            if path == '/forgot':
                return self.page('forgot.html')
            if path == '/reset':
                return self.page('reset.html')
            if not user:
                return self.reply(401, {'error':'Inicia sesión para continuar.'})
            if path == '/api/me':
                return self.reply(200, {'user':dict(user),'server_time':time.time()})
            if path == '/api/weather':
                return self.reply(200, current_weather())
            if path == '/api/time':
                return self.reply(200, {'server_time':time.time(),'timezone':'America/Guayaquil'})
            if path == '/api/conditions/current':
                active=service_terms.current(c,reception_now())
                return self.reply(200,{'terms':service_terms.metadata(active),'required':bool(active) or service_terms.required()})
            if path == '/api/conditions':
                if user['role']!='administrador':return self.reply(403,{'error':'Solo administración puede consultar el historial de publicación.'})
                rows=c.execute('SELECT * FROM service_terms ORDER BY effective_date DESC,published_at DESC').fetchall()
                return self.reply(200,{'rows':[service_terms.metadata(r) for r in rows]})
            if path == '/api/document-logo.png':
                from document_logo import monochrome_png
                return self.reply(200,monochrome_png(),'image/png')
            if path == '/api/reception-options':
                brands = [dict(r) for r in c.execute('SELECT name,category FROM brands ORDER BY name COLLATE NOCASE')]
                return self.reply(200, {'geo_metadata':GEO_METADATA,'device_types':DEVICE_TYPES,'brands':brands})
            if path.startswith('/api/geo/'):
                query=parse_qs(urlsplit(self.path).query)
                get=lambda key:query.get(key,[''])[0][:150]
                level=path[len('/api/geo/'):]
                if level not in ('provinces','cantons','parishes','localities'):
                    return self.reply(404, {'error':'Catálogo no disponible.'})
                return self.reply(200, {'rows':search_geography(level,get('province'),get('canton'),get('parish'),get('q')),'metadata':GEO_METADATA})
            if path.startswith('/api/order-by-code/'):
                code = unquote(path[len('/api/order-by-code/'):])
                row = c.execute('SELECT id FROM orders WHERE code=?',(code,)).fetchone()
                if not row:
                    return self.reply(404, {'error':'Orden no disponible.'})
                return self.reply(200, {'id':row['id']})
            detail = re.fullmatch(r'/api/orders/([0-9]+)(?:/(qr\.(svg|png)|receipt\.pdf|thermal\.pdf))?', path)
            if detail:
                row = c.execute('SELECT o.*,d.category type,d.brand,d.model,d.serial,d.color,c.name client,c.identification,c.phone,c.email,c.province,c.city,c.address,c.location_reference,s.label status_label FROM orders o JOIN devices d ON d.id=o.device_id JOIN clients c ON c.id=d.client_id JOIN statuses s ON s.code=o.status WHERE o.id=?',(int(detail[1]),)).fetchone()
                if not row:
                    return self.reply(404, {'error':'Orden no disponible.'})
                code = row['code'] or 'OP-'+str(row['id']).zfill(5)
                if detail[3]:
                    return self.reply(200, qr_image(row['qr_url'],detail[3]), 'image/svg+xml' if detail[3]=='svg' else 'image/png')
                if detail[2] in ('receipt.pdf','thermal.pdf'):
                    from receipt_pdf import render_receipt
                    pdf_order=dict(row)
                    if row['reception_snapshot']:
                        pdf_order.update(json.loads(row['reception_snapshot']))
                    service_terms.attach(c,pdf_order)
                    if detail[2]=='thermal.pdf':
                        from thermal_pdf import render_thermal
                        return self.reply(200,render_thermal(pdf_order),'application/pdf')
                    return self.reply(200, render_receipt(pdf_order), 'application/pdf')
                result = dict(row)
                result.pop('request_key', None)
                if result['reception_snapshot']:
                    result.update(json.loads(result['reception_snapshot']))
                result.pop('reception_snapshot',None)
                result['code'] = code
                service_terms.attach(c,result)
                return self.reply(200, {'order':result})
            if path in ('/api/orders', '/api/clients', '/api/devices'):
                query = parse_qs(urlsplit(self.path).query)
                term = query.get('q', [''])[0][:150]
                try:
                    page = max(1, int(query.get('page', ['1'])[0]))
                except ValueError:
                    return self.reply(400, {'error':'Página inválida.'})
                if path == '/api/orders':
                    source = 'orders o JOIN devices d ON d.id=o.device_id JOIN clients c ON c.id=d.client_id JOIN statuses s ON s.code=o.status'
                    columns = 'o.id,o.code,o.created_at,o.problem,o.status status_code,s.label status,d.category type,d.brand,d.model,c.name client'
                    search = "COALESCE(o.code,'OP-'||printf('%05d',o.id))||' '||CAST(o.id AS TEXT)||' '||c.name||' '||COALESCE(d.brand,'')||' '||COALESCE(d.model,'')||' '||o.problem||' '||s.label"
                    active = query.get('active', [''])[0] == '1'
                    where = ' AND o.status != \'entregado\'' if active else ''
                    ordering = 'o.id DESC'
                elif path == '/api/clients':
                    source, columns = 'clients c', 'c.id,c.name,c.phone,c.email'
                    search = "c.name||' '||COALESCE(c.phone,'')||' '||COALESCE(c.email,'')"
                    where, ordering = '', 'c.id DESC'
                else:
                    source = 'devices d JOIN clients c ON c.id=d.client_id'
                    columns = 'd.id,d.client_id,c.name client,d.category type,d.brand,d.model,d.serial'
                    search = "c.name||' '||COALESCE(d.brand,'')||' '||COALESCE(d.model,'')||' '||COALESCE(d.serial,'')"
                    where, ordering = '', 'd.id DESC'
                condition = f' WHERE instr(lower({search}),lower(?))>0' + where
                total = c.execute('SELECT COUNT(*) FROM '+source+condition, (term,)).fetchone()[0]
                rows = [dict(r) for r in c.execute('SELECT '+columns+' FROM '+source+condition+' ORDER BY '+ordering+' LIMIT 50 OFFSET ?', (term,(page-1)*50))]
                return self.reply(200, {'rows':rows,'total':total,'page':page,'pages':max(1,(total+49)//50)})
            if path == '/api/reports':
                counts = [dict(r) for r in c.execute('SELECT s.code,s.label,COUNT(o.id) total FROM statuses s LEFT JOIN orders o ON o.status=s.code GROUP BY s.code ORDER BY s.rowid')]
                return self.reply(200, {'statuses':counts,'clients':c.execute('SELECT COUNT(*) FROM clients').fetchone()[0],'devices':c.execute('SELECT COUNT(*) FROM devices').fetchone()[0]})
            if path == '/api/settings':
                if user['role'] != 'administrador':
                    return self.reply(403, {'error':'Solo administración puede acceder a la configuración.'})
                return self.reply(200, {'profile':{k:user[k] for k in ('name','username','email','role')},'accounts':[dict(r) for r in c.execute('SELECT name,username,role,active FROM users ORDER BY id')],'smtp_configured':bool(os.getenv('SMTP_HOST')),'origin':os.getenv('APP_URL','http://127.0.0.1:8010')})
            if path == '/api/dashboard':
                counts = {r['code']:r['total'] for r in c.execute('SELECT s.code,COUNT(o.id) total FROM statuses s LEFT JOIN orders o ON o.status=s.code GROUP BY s.code')}
                rows = [dict(r) for r in c.execute('SELECT o.id,o.code,o.created_at,o.problem,s.label status,d.category type,d.brand,d.model,c.name client FROM orders o JOIN statuses s ON s.code=o.status JOIN devices d ON d.id=o.device_id JOIN clients c ON c.id=d.client_id ORDER BY o.id DESC LIMIT 10')]
                return self.reply(200, {'counts':counts,'total':sum(counts.values()),'orders':rows})
        return self.reply(404, {'error':'Recurso no disponible.'})

    def do_POST(self):
        try:
            origin = self.headers.get('Origin')
            expected = os.getenv('APP_URL', 'http://127.0.0.1:8010').rstrip('/')
            # JSON + origen exacto: formularios externos no pueden enviar estos POST.
            if origin != expected or self.headers.get_content_type() != 'application/json':
                return self.reply(403, {'error':'Solicitud no autorizada.'})
            length = int(self.headers.get('Content-Length', '0'))
            if length <= 0 or length > 16384:
                return self.reply(400, {'error':'Solicitud inválida.'})
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict) or any(not isinstance(v, (str, bool)) for v in data.values()):
                return self.reply(400, {'error':'Datos inválidos.'})
            path = urlsplit(self.path).path
            with connect() as c:
                c.execute('BEGIN IMMEDIATE')
                if path == '/api/login':
                    login, password = str(data.get('login','')).strip(), str(data.get('password',''))
                    blocked_ip = limited(c, 'login-ip:'+digest(self.client_address[0]), limit=30)
                    blocked_user = limited(c, 'login-user:'+digest(login.casefold()))
                    if blocked_ip or blocked_user:
                        return self.reply(429, {'error':'Demasiados intentos. Intenta de nuevo en 15 minutos.'})
                    row = c.execute('SELECT * FROM users WHERE (username=? OR email=?) AND active=1', (login,login)).fetchone()
                    valid = password_ok(password, row['password_hash'] if row else DUMMY_HASH)
                    if not row or not valid:
                        audit(c, None, 'login_failed')
                        return self.reply(401, {'error':'Usuario o contraseña incorrectos.'})
                    _, previous = self.session(c)
                    c.execute('DELETE FROM sessions WHERE token_hash=?', (digest(previous),))
                    remember = data.get('remember') is True
                    token, csrf, age = make_session(c, row['id'], remember)
                    audit(c, row['id'], 'login')
                    return self.reply(200, {'ok':True}, cookie=self.cookie(token, age if remember else None))
                if path == '/api/forgot':
                    email = str(data.get('email','')).strip()
                    ip_blocked = limited(c, 'reset-ip:'+digest(self.client_address[0]), 5)
                    mail_blocked = limited(c, 'reset-email:'+digest(email.casefold()), 3)
                    row = c.execute('SELECT id,email FROM users WHERE email=? AND active=1', (email,)).fetchone()
                    if row and not ip_blocked and not mail_blocked:
                        token = secrets.token_urlsafe(32)
                        c.execute('DELETE FROM reset_tokens WHERE user_id=?', (row['id'],))
                        c.execute('INSERT INTO reset_tokens VALUES (?,?,?)', (digest(token),row['id'],int(time.time())+1200))
                        try:
                            send_reset(row['email'], token)
                            audit(c, row['id'], 'reset_email_sent')
                        except (OSError, RuntimeError, smtplib.SMTPException):
                            c.execute('DELETE FROM reset_tokens WHERE token_hash=?', (digest(token),))
                            audit(c, None, 'reset_delivery_failed')
                    return self.reply(200, {'ok':True,'message':'Si la dirección corresponde a una cuenta habilitada, recibirás instrucciones por correo.'})
                if path == '/api/reset':
                    if limited(c, 'reset-use:'+digest(self.client_address[0]), 10):
                        return self.reply(429, {'error':'Demasiados intentos. Intenta más tarde.'})
                    password = str(data.get('password',''))
                    if not 12 <= len(password) <= 256:
                        return self.reply(400, {'error':'Usa una contraseña de 12 a 256 caracteres.'})
                    token = str(data.get('token',''))
                    row = c.execute('SELECT t.user_id FROM reset_tokens t JOIN users u ON u.id=t.user_id WHERE token_hash=? AND expires>? AND u.active=1', (digest(token),int(time.time()))).fetchone()
                    if not row:
                        return self.reply(400, {'error':'El enlace no es válido o ha caducado.'})
                    c.execute('UPDATE users SET password_hash=? WHERE id=?', (password_hash(password),row['user_id']))
                    c.execute('DELETE FROM reset_tokens WHERE user_id=?', (row['user_id'],))
                    c.execute('DELETE FROM sessions WHERE user_id=?', (row['user_id'],))
                    audit(c, row['user_id'], 'password_reset')
                    return self.reply(200, {'ok':True})
                user, token = self.session(c)
                if not user:
                    return self.reply(401, {'error':'Inicia sesión para continuar.'})
                if not hmac.compare_digest(self.headers.get('X-CSRF-Token',''), user['csrf']):
                    return self.reply(403, {'error':'La sesión de seguridad no es válida. Recarga la página.'})
                if path == '/api/logout':
                    c.execute('DELETE FROM sessions WHERE token_hash=?', (digest(token),))
                    audit(c, user['id'], 'logout')
                    return self.reply(200, {'ok':True}, cookie=self.cookie('',0))
                if path == '/api/conditions':
                    if user['role']!='administrador':return self.reply(403,{'error':'Solo administración puede publicar condiciones.'})
                    tid,errors=service_terms.publish(c,data,user,reception_now())
                    if errors:return self.reply(400,{'error':'Revisa los datos de publicación.','fields':errors})
                    audit(c,user['id'],'service_terms_published')
                    return self.reply(201,{'ok':True,'id':tid})
                if path in ('/api/clients', '/api/devices', '/api/order-status', '/api/settings'):
                    if user['role'] != 'administrador':
                        return self.reply(403, {'error':'Solo administración puede realizar esta operación.'})
                    if path == '/api/settings':
                        name, email = str(data.get('name','')).strip(), str(data.get('email','')).strip()
                        if not name or len(name)>150 or len(email)>254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email):
                            return self.reply(400, {'error':'Completa un nombre y correo válidos.'})
                        if c.execute('SELECT 1 FROM users WHERE email=? AND id!=?', (email,user['id'])).fetchone():
                            return self.reply(400, {'error':'Ese correo no está disponible.'})
                        c.execute('UPDATE users SET name=?,email=? WHERE id=?', (name,email,user['id']))
                        audit(c,user['id'],'profile_updated',user['id'])
                    elif path == '/api/order-status':
                        status = str(data.get('status',''))
                        oid = str(data.get('id',''))
                        if not c.execute('SELECT 1 FROM statuses WHERE code=?',(status,)).fetchone() or not c.execute('SELECT 1 FROM orders WHERE id=?',(oid,)).fetchone():
                            return self.reply(400, {'error':'Orden o estado inválido.'})
                        c.execute('UPDATE orders SET status=? WHERE id=?', (status,oid))
                        audit(c,user['id'],'order_status_updated',int(oid))
                    else:
                        table = 'clients' if path == '/api/clients' else 'devices'
                        keys = ('name','phone','email') if table == 'clients' else ('client_id','type','brand','model','serial')
                        values = [str(data.get(k,'')).strip() for k in keys]
                        if any(len(v)>150 for v in values):
                            return self.reply(400, {'error':'Los campos admiten hasta 150 caracteres.'})
                        if table == 'clients':
                            if not values[0] or (values[2] and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',values[2])):
                                return self.reply(400, {'error':'Indica un nombre y un correo válido si corresponde.'})
                        elif values[1] not in DEVICE_TYPES or not c.execute('SELECT 1 FROM clients WHERE id=?',(values[0],)).fetchone():
                            return self.reply(400, {'error':'Selecciona un cliente y tipo de equipo válidos.'})
                        if table == 'devices':
                            category = values[1]
                            keys = (*keys, 'category')
                            values[1] = legacy_type(category)
                            values.append(category)
                            remember_brand(c,values[2],category)
                        entity_id = str(data.get('id',''))
                        if entity_id:
                            if not c.execute('SELECT 1 FROM '+table+' WHERE id=?',(entity_id,)).fetchone():
                                return self.reply(404, {'error':'Registro no disponible.'})
                            c.execute('UPDATE '+table+' SET '+','.join(k+'=?' for k in keys)+' WHERE id=?',(*values,entity_id))
                        else:
                            entity_id = c.execute('INSERT INTO '+table+'('+','.join(keys)+') VALUES ('+','.join('?' for _ in keys)+')',values).lastrowid
                        audit(c,user['id'],table+'_saved',int(entity_id))
                    return self.reply(200, {'ok':True})
                if path == '/api/orders':
                    fields, errors = validate_order(data)
                    if errors:
                        return self.reply(400, {'error':'Revisa los campos señalados.','fields':errors})
                    request_key = str(data.get('request_key','')) or None
                    if request_key:
                        previous = c.execute('SELECT id,code,created_by FROM orders WHERE request_key=?',(request_key,)).fetchone()
                        if previous:
                            if previous['created_by'] != user['id']:
                                return self.reply(409, {'error':'Identificador de envío no disponible. Reabre el formulario.'})
                            return self.reply(200, {'ok':True,'id':previous['id'],'code':previous['code']})
                    received=reception_now()
                    terms=service_terms.current(c,received)
                    if not terms and service_terms.required():
                        return self.reply(503,{'error':'Publica las condiciones aprobadas y vigentes antes de registrar recepciones.','fields':{'terms_accept':'No hay condiciones vigentes configuradas.'}})
                    if terms:
                        if str(data.get('terms_document_id',''))!=terms['id']:
                            return self.reply(409,{'error':'Las condiciones vigentes han cambiado. Revísalas y registra nuevamente la aceptación.','fields':{'terms_accept':'La versión debe revisarse nuevamente.'}})
                        if data.get('terms_accept') is not True:
                            return self.reply(400,{'error':'Registra la aceptación de las condiciones.','fields':{'terms_accept':'El cliente debe revisar y aceptar las condiciones antes de guardar.'}})
                    client_keys = ('phone','email','identification','document_type','trade_name','province','province_code','canton','canton_code','parish','parish_code','city','locality_code','address','main_street','secondary_street','building_number','location_reference','geo_version')
                    client_id = c.execute('INSERT INTO clients(name,'+','.join(client_keys)+') VALUES ('+','.join('?' for _ in range(len(client_keys)+1))+')',
                        (fields['client'],*(fields[k] for k in client_keys))).lastrowid
                    device_id = c.execute('INSERT INTO devices(client_id,type,category,brand,model,serial,color) VALUES (?,?,?,?,?,?,?)',
                        (client_id,legacy_type(fields['type']),fields['type'],fields['brand'],fields['model'],fields['serial'],fields['color'])).lastrowid
                    remember_brand(c,fields['brand'],fields['type'])
                    number_date = received.strftime('%Y%m%d')
                    c.execute('INSERT INTO daily_order_sequences(reception_date,value) VALUES (?,1) ON CONFLICT(reception_date) DO UPDATE SET value=value+1',(number_date,))
                    sequence = c.execute('SELECT value FROM daily_order_sequences WHERE reception_date=?',(number_date,)).fetchone()[0]
                    code = order_code(number_date,sequence)
                    oid = c.execute("INSERT INTO orders(device_id,status,problem,created_by,created_at,accessories,physical_condition,technician_notes,code,request_key,received_at,number_date,daily_sequence) VALUES (?,'pendiente',?,?,?,?,?,?,?,?,?,?,?)",
                        (device_id,fields['problem'],user['id'],int(received.timestamp()),fields['accessories'],fields['physical_condition'],fields['technician_notes'],code,request_key,received.isoformat(timespec='microseconds'),number_date,sequence)).lastrowid
                    c.execute('UPDATE orders SET qr_url=? WHERE id=?',(order_url(code),oid))
                    c.execute('UPDATE orders SET reception_snapshot=? WHERE id=?',(json.dumps(fields,ensure_ascii=False),oid))
                    if terms:
                        c.execute('UPDATE orders SET terms_document_id=?,terms_acceptance_id=?,terms_accepted_at=?,terms_mechanism=?,terms_acceptor=?,terms_actor_id=? WHERE id=?',
                                  (terms['id'],secrets.token_hex(16),received.isoformat(timespec='microseconds'),service_terms.MECHANISM,fields['client'],user['id'],oid))
                        audit(c,user['id'],'service_terms_accepted',oid)
                    audit(c, user['id'], 'order_created', oid)
                    return self.reply(201, {'ok':True,'id':oid,'code':code})
            return self.reply(404, {'error':'Recurso no disponible.'})
        except (ValueError, json.JSONDecodeError):
            self.reply(400, {'error':'Solicitud inválida.'})
        except Exception:
            self.reply(500, {'error':'No se pudo completar la operación.'})


def main():
    load_env()
    os.umask(0o077)
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['serve','create-admin','create-technician','migrate'])
    args = parser.parse_args()
    migrate()
    if args.command.startswith('create-'):
        role = 'administrador' if args.command == 'create-admin' else 'tecnico'
        name = input('Nombre: ').strip()
        username = input('Usuario: ').strip()
        email = input('Correo: ').strip()
        password = getpass.getpass('Contraseña (mínimo 12 caracteres): ')
        repeat = getpass.getpass('Repetir contraseña: ')
        if not name or not re.fullmatch(r'[a-zA-Z0-9_.-]{3,50}', username) or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or not 12<=len(password)<=256 or password != repeat:
            raise SystemExit('Datos inválidos o contraseñas diferentes; no se creó la cuenta.')
        with connect() as c:
            c.execute('BEGIN IMMEDIATE')
            if role == 'administrador' and c.execute("SELECT 1 FROM users WHERE role='administrador'").fetchone():
                raise SystemExit('Ya existe un administrador. No se modificó ninguna cuenta.')
            uid = c.execute('INSERT INTO users(username,email,name,password_hash,role,created_at) VALUES (?,?,?,?,?,?)',(username,email,name,password_hash(password),role,int(time.time()))).lastrowid
            audit(c,uid,'account_created',uid)
        print('Cuenta creada. No hay registro público.')
    elif args.command == 'serve':
        port = int(os.getenv('PORT','8010'))
        host = os.getenv('BIND_HOST', '127.0.0.1')
        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            raise SystemExit('BIND_HOST debe ser una dirección IPv4 local.')
        if address.version != 4 or address.is_unspecified or not (address.is_loopback or address.is_private) or address.is_multicast or address.is_link_local:
            raise SystemExit('Esta evaluación solo admite una IPv4 privada o de loopback explícita.')
        origin = os.getenv('APP_URL', f'http://{host}:{port}').rstrip('/')
        parsed = urlsplit(origin)
        if parsed.scheme not in ('http','https') or parsed.hostname != host or parsed.port != port or parsed.path or parsed.query or parsed.fragment or parsed.username:
            raise SystemExit(f'APP_URL debe corresponder a la dirección de acceso, por ejemplo http://{host}:{port}')
        os.environ['APP_URL'] = origin
        try:
            server = ThreadingHTTPServer((host,port), Handler)
        except OSError as error:
            raise SystemExit(f'No se pudo iniciar el servidor local: {error}. Ejecuta este comando en tu terminal de Omarchy.')
        print(f'ÓRDENES PRO: {origin}', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('\nServidor detenido.')
        finally:
            server.server_close()


if __name__ == '__main__':
    main()
